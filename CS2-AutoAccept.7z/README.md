# CS2-AutoAccept

Automatically accepts found game.

# Installation

Run `run.bat`, wait for modules to install, and you're ready to go!

Press CTRL + G to stop

This project is a small part of my big project called TelegramPCControl, make sure to check out it on the release.